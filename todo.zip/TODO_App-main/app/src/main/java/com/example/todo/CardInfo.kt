package com.example.todo

data class CardInfo(
    var title:String,
    var priority:String
)
